Tweetie PHP API
===

Simple PHP API for jQuery Tweetie.

# Config

Edit the `config.php` file and replace the variables with your Twitter Authentication Keys.
