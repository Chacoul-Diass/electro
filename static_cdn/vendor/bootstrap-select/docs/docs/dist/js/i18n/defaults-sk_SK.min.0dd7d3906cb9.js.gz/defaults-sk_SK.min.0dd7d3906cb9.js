/*!
 * Bootstrap-select v1.13.2 (https://developer.snapappointments.com/bootstrap-select)
 *
 * Copyright 2012-2018 SnapAppointments, LLC
 * Licensed under MIT (https://github.com/snapappointments/bootstrap-select/blob/master/LICENSE)
 */

!function(e,n){void 0===e&&void 0!==window&&(e=window),"function"==typeof define&&define.amd?define(["jquery"],function(e){return n(e)}):"object"==typeof module&&module.exports?module.exports=n(require("jquery")):n(e.jQuery)}(this,function(e){e.fn.selectpicker.defaults={noneSelectedText:"Vyberte zo zoznamu",noneResultsText:"Pre výraz {0} neboli nájdené žiadne výsledky",countSelectedText:"Vybrané {0} z {1}",maxOptionsText:["Limit prekročený ({n} {var} max)","Limit skupiny prekročený ({n} {var} max)",["položiek","položka"]],selectAllText:"Vybrať všetky",deselectAllText:"Zrušiť výber",multipleSeparator:", "}});